function wand_fired( gun_entity_id )
    --GamePrint("fired client")
end